//
//  ViewController.swift
//  3-turDonusumleri
//
//  Created by wissen on 22/10/16.
//  Copyright © 2016 wissen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    // hakanozer02@gmail.com
    
    @IBOutlet weak var lblSonuc: UILabel!
    @IBOutlet weak var txtBoy: UITextField!
    @IBOutlet weak var txtKilo: UITextField!
    @IBAction func fncHesapla(_ sender: UIButton) {
        
        let b = txtBoy.text
        let k = txtKilo.text
        
        let db = Int(b!)
        let dk = Int(k!)
        
        let hesapla = db! - dk!
        if hesapla >= 100 {
            lblSonuc.text = "Fit bir vucuda sahipsiniz"
            print("Fit bir vucuda sahipsiniz")
        }else {
            lblSonuc.text = "Kio Verin :)"
            print("Kio Verin :)")
        }
        
        
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let kilo = "85"
        let boy = "175"
        
        let dkilo = Int(kilo)
        let dboy = Int(boy)
        
        let fkilo = Float(boy)
        
        
        let fark = dboy! - dkilo!
        print("Fark \(fark)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

