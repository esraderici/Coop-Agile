//
//  ViewController.swift
//  2-degiskenler
//
//  Created by wissen on 22/10/16.
//  Copyright © 2016 wissen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // değişken tanımlama
        // let , var
        // let - sabit, daha sonradan değerini değiştirmeyeceğimiz anahtar kelimedir.
        let adi = "Ali"
        // adi = "Mehmet"
        print("merhaba console ben \(adi)")
        
        let soyadi:String = "Bilmem"
        let (a,b) = ("as","sa")
        print("a değeri \(a)")
    
        
        // var kullanımı
        var yasi = 35
        yasi = 25
        var renk = UIColor.black
        renk = UIColor.blue
        
        
        // String değişken türü
        // adınız, nick, yasi
        let aadi = "Hasan"
        let asoyadi = "Bilirim"
        let birlestir = "\(aadi) \(asoyadi)"
        print(birlestir)
        
        
        // matematiksel ifadeler
        // int - tam sayı veri türleri
        let s1 = 25
        let s2 = 36
        let toplam = s1 + s2
        print("Toplam \(toplam)")
        
        
        
        // ondalıklı değer türü
        let o1 = Float(10.5)
        let o2 = Float(66.4)
        let ftoplam:Float = o1 + o2
        print("Ondalık Toplam \(ftoplam)")
        
        // büyük ondalıklı değer
        // double
        let d1:Double = 10.5
        let d2 = 66.4
        let dtoplam = d1 + d2
        print("Ondalık büyük Toplam \(dtoplam)")
        
        
        // boolean veri türü
        // true - false
        let durum1 = true
        
        
        // icon lu değişken türleri
        let 🙃 = true
        print(🙃)
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

