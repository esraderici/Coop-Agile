//
//  ViewController.swift
//  2-diziler
//
//  Created by wissen on 23/10/16.
//  Copyright © 2016 wissen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // birden fazla değerin bir değişken altında toplanması
    var dizi1 = [""]
    let dizi2:[String] = []
    let dizi3:[Any] = [1,"ali", true]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // diziye eleman ekleme
        dizi1.append("Ali")
        dizi1.append("Veli")
        dizi1.append("Zehra")
        
        
        // eleman değerine erişim
        print(dizi1[1])
        
        // eleman değerini değiştirme
        dizi1[0] = "Fenerbahçe"
        
        // sıraya göre eleman ekleme
        dizi1.insert("Hasan", at: 1)
        
        // eleman çıkarma
        dizi1.remove(at: 1)
        
        
        // eleman değerlerine toplam erişim
        var i = 0
        for item in dizi1 {
            print("index \(i) val \(item)")
            i += 1
        }
        
        
        // dizi eleman değerini silme
        dizi1 = []
        dizi1.removeAll()
        
        // dizinin değerini farklı bir dizi ile değiştirme
        let dizi4 = ["a","b","c"]
        dizi1 = dizi4
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

